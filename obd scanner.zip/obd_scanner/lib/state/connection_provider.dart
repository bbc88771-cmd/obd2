import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:permission_handler/permission_handler.dart';

import '../transport/obd_transport.dart';
import '../transport/ble_transport.dart';
import '../transport/wifi_transport.dart';
import '../transport/bt_classic_transport.dart';
import '../core/obd_service.dart';

/// Тип транспорта, выбранный пользователем.
enum TransportKind { ble, btClassic, wifi }

final transportKindProvider = StateProvider<TransportKind>((ref) {
  // на iOS BT Classic недоступен — по умолчанию BLE
  return TransportKind.ble;
});

/// Фабрика транспорта по выбранному типу.
ObdTransport _buildTransport(TransportKind kind) {
  switch (kind) {
    case TransportKind.ble:
      return BleTransport();
    case TransportKind.wifi:
      return WifiTransport(); // 192.168.0.10:35000 по умолчанию
    case TransportKind.btClassic:
      return BtClassicTransport();
  }
}

/// Конечный автомат соединения + жизненный цикл ObdService.
class ConnectionController extends StateNotifier<ConnectionUiState> {
  ConnectionController() : super(const ConnectionUiState());

  ObdService? _service;
  ObdService? get service => _service;

  Future<void> _ensurePermissions(TransportKind kind) async {
    if (kind == TransportKind.wifi) return; // Wi-Fi не требует BT-разрешений
    if (Platform.isAndroid || Platform.isIOS) {
      await [
        Permission.bluetoothScan,
        Permission.bluetoothConnect,
        Permission.locationWhenInUse, // нужно для скана на старых Android
      ].request();
    }
  }

  Future<void> connect(TransportKind kind) async {
    try {
      state = state.copyWith(link: LinkState.connecting, error: null);
      await _ensurePermissions(kind);

      final transport = _buildTransport(kind);
      final service = ObdService(transport);
      _service = service;

      // транслируем состояние линка в UI
      transport.linkState.listen((s) {
        state = state.copyWith(link: s);
        if (s == LinkState.disconnected) _service?.stopPolling();
      });

      await transport.connect();

      state = state.copyWith(link: LinkState.initializing);
      await service.initialize();

      service.startPolling();
      state = state.copyWith(link: LinkState.connected);
    } catch (e) {
      state = state.copyWith(link: LinkState.error, error: e.toString());
    }
  }

  Future<void> disconnect() async {
    await _service?.transport.disconnect();
    await _service?.dispose();
    _service = null;
    state = const ConnectionUiState();
  }
}

class ConnectionUiState {
  final LinkState link;
  final String? error;
  const ConnectionUiState({this.link = LinkState.disconnected, this.error});

  ConnectionUiState copyWith({LinkState? link, String? error}) =>
      ConnectionUiState(link: link ?? this.link, error: error);
}

final connectionProvider =
    StateNotifierProvider<ConnectionController, ConnectionUiState>(
  (ref) => ConnectionController(),
);

/// Стрим телеметрии для дашборда.
final telemetryProvider = StreamProvider<Telemetry>((ref) {
  final ctrl = ref.watch(connectionProvider.notifier);
  final svc = ctrl.service;
  if (svc == null) return const Stream.empty();
  return svc.telemetry;
});
