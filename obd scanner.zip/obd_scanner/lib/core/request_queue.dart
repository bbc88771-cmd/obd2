import 'dart:async';
import 'obd_connection.dart';

/// Последовательная очередь команд.
///
/// ELM327 полудуплексный и обрабатывает РОВНО одну команду за раз.
/// Если послать вторую до прихода '>', ответы слипнутся в кашу.
/// Очередь гарантирует строгий порядок «запрос → ответ → следующий».
class RequestQueue {
  final ObdConnection conn;
  final List<_Item> _items = [];
  bool _pumping = false;

  /// Микропауза между командами — дешёвым клонам нужно «продохнуть».
  final Duration gap;

  RequestQueue(this.conn, {this.gap = const Duration(milliseconds: 25)});

  /// Поставить команду в очередь. Возвращает future с её ответом.
  Future<String> enqueue(String cmd, {Duration? timeout}) {
    final item = _Item(cmd, Completer<String>(), timeout);
    _items.add(item);
    _pump(); // запускаем «насос», если стоял
    return item.completer.future;
  }

  Future<void> _pump() async {
    if (_pumping) return;
    _pumping = true;

    while (_items.isNotEmpty) {
      final item = _items.removeAt(0);
      try {
        final resp = item.timeout != null
            ? await conn.send(item.cmd, timeout: item.timeout!)
            : await conn.send(item.cmd);
        if (!item.completer.isCompleted) item.completer.complete(resp);
      } catch (e) {
        // один таймаут НЕ должен ронять всю очередь
        if (!item.completer.isCompleted) item.completer.completeError(e);
      }
      await Future.delayed(gap);
    }

    _pumping = false;
  }

  void clear() {
    for (final i in _items) {
      if (!i.completer.isCompleted) {
        i.completer.completeError(StateError("Очередь очищена"));
      }
    }
    _items.clear();
  }
}

class _Item {
  final String cmd;
  final Completer<String> completer;
  final Duration? timeout;
  _Item(this.cmd, this.completer, this.timeout);
}
