import 'dart:async';
import '../transport/obd_transport.dart';

/// Превращает «рваный» поток байтов от адаптера в цельные текстовые ответы.
///
/// ELM327 завершает КАЖДЫЙ ответ символом-приглашением '>' (0x3E).
/// Байты могут приходить кусками ("41 0C", потом "1A F8\r>"),
/// поэтому копим буфер до появления '>'.
class ObdConnection {
  final ObdTransport transport;
  final StringBuffer _buffer = StringBuffer();
  Completer<String>? _pending;

  late final StreamSubscription _sub;

  ObdConnection(this.transport) {
    _sub = transport.incoming.listen(_onBytes);
  }

  void _onBytes(List<int> chunk) {
    _buffer.write(String.fromCharCodes(chunk));
    final current = _buffer.toString();

    if (current.contains('>')) {
      _buffer.clear();
      // нормализация: убираем приглашение, переводы строк и пробелы.
      // (ATS0 обычно уже убрал пробелы, но подстраховываемся)
      final clean = current
          .replaceAll('>', '')
          .replaceAll('\r', '')
          .replaceAll('\n', '')
          .replaceAll(' ', '')
          .toUpperCase()
          .trim();

      final p = _pending;
      _pending = null;
      if (p != null && !p.isCompleted) p.complete(clean);
    }
  }

  /// Отправляет одну команду и ждёт цельный ответ или таймаут.
  Future<String> send(
    String cmd, {
    Duration timeout = const Duration(milliseconds: 1500),
  }) {
    _buffer.clear(); // чистим хвосты предыдущего обмена
    final completer = Completer<String>();
    _pending = completer;

    transport.write(cmd);

    return completer.future.timeout(timeout, onTimeout: () {
      _pending = null;
      throw TimeoutException("Таймаут ответа на '$cmd'");
    });
  }

  Future<void> dispose() async => _sub.cancel();
}
