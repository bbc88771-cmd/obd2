/// Чистые функции разбора HEX-ответов ЭБУ. Без состояния — легко тестировать.
///
/// Общая логика OBD-II:
///   запрос  = <Mode><PID>           напр. "010C"  (Mode 01, PID 0C)
///   ответ   = <Mode+0x40><PID><данные A B C ...>
///             напр. "410C1AF8" → Mode 41 (=01+0x40), PID 0C, A=1A, B=F8
class ObdParsers {
  /// Маркеры мусорных/служебных ответов адаптера.
  static bool _isGarbage(String r) {
    return r.contains("NODATA") ||
        r.contains("ERROR") ||
        r.contains("SEARCHING") ||
        r.contains("UNABLE") ||
        r.contains("STOPPED") ||
        r.contains("BUFFERFULL") ||
        r.contains("CANERROR") ||
        r.isEmpty;
  }

  /// Достаёт байты данных (A, B, ...) из ответа, проверяя эхо Mode+PID.
  /// Возвращает null, если ответ битый или не тот PID.
  static List<int>? extractData(String resp, String mode, String pid) {
    if (_isGarbage(resp)) return null;

    // режем строку на пары символов = байты
    final bytes = <int>[];
    for (int i = 0; i + 2 <= resp.length; i += 2) {
      final b = int.tryParse(resp.substring(i, i + 2), radix: 16);
      if (b == null) return null; // мусорный символ
      bytes.add(b);
    }

    final modeByte = int.parse(mode, radix: 16) + 0x40; // 01 -> 41
    final pidByte = int.parse(pid, radix: 16);

    // ищем начало валидного фрейма (может быть мусор в начале строки)
    for (int i = 0; i + 1 < bytes.length; i++) {
      if (bytes[i] == modeByte && bytes[i + 1] == pidByte) {
        return bytes.sublist(i + 2); // только полезная нагрузка
      }
    }
    return null;
  }

  /// RPM (PID 0C): (A*256 + B) / 4.
  /// Два байта, разрешение ¼ об/мин → диапазон 0..16383.75.
  /// Пример: A=0x1A(26), B=0xF8(248) → (26*256+248)/4 = 6904/4 = 1726 RPM.
  static int? rpm(String resp) {
    final d = extractData(resp, "01", "0C");
    if (d == null || d.length < 2) return null;
    final v = ((d[0] * 256) + d[1]) ~/ 4;
    return (v >= 0 && v <= 16383) ? v : null; // sanity-check
  }

  /// Скорость (PID 0D): A км/ч напрямую. Один байт 0..255.
  static int? speed(String resp) {
    final d = extractData(resp, "01", "0D");
    if (d == null || d.isEmpty) return null;
    final v = d[0];
    return (v <= 255) ? v : null;
  }

  /// Температура ОЖ (PID 05): A - 40 (°C).
  /// Смещение −40 позволяет кодировать минус без знакового байта
  /// (байт 0x00 = −40 °C, 0xFF = 215 °C).
  static int? coolant(String resp) {
    final d = extractData(resp, "01", "05");
    if (d == null || d.isEmpty) return null;
    return d[0] - 40;
  }

  /// Нагрузка двигателя (PID 04): A * 100 / 255 (%).
  static double? engineLoad(String resp) {
    final d = extractData(resp, "01", "04");
    if (d == null || d.isEmpty) return null;
    return d[0] * 100 / 255;
  }

  /// Положение дросселя (PID 11): A * 100 / 255 (%).
  static double? throttle(String resp) {
    final d = extractData(resp, "01", "11");
    if (d == null || d.isEmpty) return null;
    return d[0] * 100 / 255;
  }

  /// Напряжение по команде ELM327 "ATRV" (не OBD-PID, особый ответ "12.3V").
  static double? voltage(String resp) {
    final clean = resp.replaceAll("V", "");
    return double.tryParse(clean);
  }

  // ─────────────── РАСШИРЕННЫЕ PID ───────────────

  /// Температура впускного воздуха (PID 0F): A - 40 (°C). Та же логика смещения.
  static int? intakeTemp(String resp) {
    final d = extractData(resp, "01", "0F");
    if (d == null || d.isEmpty) return null;
    return d[0] - 40;
  }

  /// Уровень топлива в баке (PID 2F): A * 100 / 255 (%).
  static double? fuelLevel(String resp) {
    final d = extractData(resp, "01", "2F");
    if (d == null || d.isEmpty) return null;
    return d[0] * 100 / 255;
  }

  /// Расход воздуха MAF (PID 10): (A*256 + B) / 100 (грамм/сек).
  /// Два байта, разрешение 0.01 г/с. Нужен для расчёта мгновенного расхода топлива.
  static double? maf(String resp) {
    final d = extractData(resp, "01", "10");
    if (d == null || d.length < 2) return null;
    return ((d[0] * 256) + d[1]) / 100;
  }

  /// Давление во впускном коллекторе MAP (PID 0B): A кПа напрямую (абсолютное).
  /// Для турбо: наддув = MAP - атмосферное(~101 кПа).
  static int? mapPressure(String resp) {
    final d = extractData(resp, "01", "0B");
    if (d == null || d.isEmpty) return null;
    return d[0];
  }

  /// Давление топлива (PID 0A): A * 3 (кПа). Множитель 3 = разрешение датчика.
  static int? fuelPressure(String resp) {
    final d = extractData(resp, "01", "0A");
    if (d == null || d.isEmpty) return null;
    return d[0] * 3;
  }

  /// Угол опережения зажигания (PID 0E): A/2 - 64 (°).
  /// Смещение −64 позволяет кодировать отрицательные углы (запаздывание).
  static double? timingAdvance(String resp) {
    final d = extractData(resp, "01", "0E");
    if (d == null || d.isEmpty) return null;
    return d[0] / 2 - 64;
  }

  /// Температура окружающего воздуха (PID 46): A - 40 (°C).
  static int? ambientTemp(String resp) {
    final d = extractData(resp, "01", "46");
    if (d == null || d.isEmpty) return null;
    return d[0] - 40;
  }

  /// Обороты по двум байтам — общий помощник, если нужен другой PID с той же формулой.
  /// Лямбда O2 (PID 24, широкополосный): ((A*256+B)/65536)*2 — коэффициент эквивалентности.
  static double? lambda(String resp) {
    final d = extractData(resp, "01", "24");
    if (d == null || d.length < 2) return null;
    return ((d[0] * 256) + d[1]) / 65536 * 2;
  }

  /// Пробег с момента сброса ошибок (PID 31): A*256 + B (км).
  static int? distanceSinceClear(String resp) {
    final d = extractData(resp, "01", "31");
    if (d == null || d.length < 2) return null;
    return (d[0] * 256) + d[1];
  }

  /// Расчётный мгновенный расход топлива (л/ч) из MAF.
  /// Формула для бензина (AFR≈14.7, плотность≈0.745 кг/л):
  ///   л/ч = (MAF[г/с] * 3600) / (14.7 * 745)
  static double? fuelRateFromMaf(double mafGramsPerSec) {
    return (mafGramsPerSec * 3600) / (14.7 * 745);
  }

  /// Чтение DTC (Mode 03). Каждый код = 2 байта.
  ///   старшие 2 бита 1-го байта → буква системы (P/C/B/U)
  ///   биты 5-4 → первая цифра, биты 3-0 → вторая цифра
  ///   2-й байт → последние две шестнадцатеричные цифры
  /// Пример: байты 01 33 → P0133.
  static List<String> dtc(String resp) {
    if (_isGarbage(resp) || !resp.startsWith("43")) return [];
    final hex = resp.substring(2); // отрезаем эхо режима "43"
    final codes = <String>[];
    const letters = ['P', 'C', 'B', 'U'];

    for (int i = 0; i + 4 <= hex.length; i += 4) {
      final chunk = hex.substring(i, i + 4);
      if (chunk == "0000") continue; // пустой слот

      final first = int.parse(chunk.substring(0, 2), radix: 16);
      final letter = letters[(first & 0xC0) >> 6];   // биты 7-6
      final d1 = (first & 0x30) >> 4;                // биты 5-4
      final d2 = first & 0x0F;                       // биты 3-0
      final rest = chunk.substring(2);               // байт B как есть

      codes.add("$letter$d1${d2.toRadixString(16)}$rest".toUpperCase());
    }
    return codes;
  }
}

/// Каталог PID для удобного опроса.
class Pid {
  final String label;
  final String cmd;     // что слать, напр. "010C"
  final String unit;
  const Pid(this.label, this.cmd, this.unit);

  static const rpm = Pid("Обороты", "010C", "об/мин");
  static const speed = Pid("Скорость", "010D", "км/ч");
  static const coolant = Pid("Темп. ОЖ", "0105", "°C");
  static const load = Pid("Нагрузка", "0104", "%");
  static const throttle = Pid("Дроссель", "0111", "%");

  // расширенные
  static const intakeTemp = Pid("Темп. впуска", "010F", "°C");
  static const fuelLevel = Pid("Топливо", "012F", "%");
  static const maf = Pid("MAF", "0110", "г/с");
  static const map = Pid("Наддув (MAP)", "010B", "кПа");
  static const fuelPressure = Pid("Давл. топлива", "010A", "кПа");
  static const timing = Pid("Опереж. зажиг.", "010E", "°");
  static const ambient = Pid("Темп. за бортом", "0146", "°C");
  static const lambda = Pid("Лямбда", "0124", "λ");
  static const distance = Pid("Пробег с DTC", "0131", "км");
}
